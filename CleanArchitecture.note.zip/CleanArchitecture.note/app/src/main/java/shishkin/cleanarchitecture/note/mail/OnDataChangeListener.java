package shishkin.cleanarchitecture.note.mail;

/**
 * Created by Shishkin on 13.02.2018.
 */

public interface OnDataChangeListener {
    void onChange(String table);
}
