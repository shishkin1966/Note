package shishkin.cleanarchitecture.note.screen.note;

import com.cleanarchitecture.sl.ui.fragment.IFragment;

/**
 * Created by Shishkin on 17.03.2018.
 */

public interface NoteView extends IFragment {

}
