package com.cleanarchitecture.sl.model;

/**
 * Created by Shishkin on 21.11.2017.
 */

public interface ModelInteractor {
}
