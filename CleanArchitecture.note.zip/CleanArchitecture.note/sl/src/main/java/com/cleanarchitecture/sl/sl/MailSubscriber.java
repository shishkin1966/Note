package com.cleanarchitecture.sl.sl;

import com.cleanarchitecture.sl.state.Stateable;

public interface MailSubscriber extends ModuleSubscriber, Stateable {
}
