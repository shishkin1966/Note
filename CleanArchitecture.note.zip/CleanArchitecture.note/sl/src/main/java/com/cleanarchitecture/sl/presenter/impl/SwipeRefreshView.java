package com.cleanarchitecture.sl.presenter.impl;

import android.support.v4.widget.SwipeRefreshLayout;

/**
 * Created by Shishkin on 18.02.2018.
 */

public interface SwipeRefreshView {
    SwipeRefreshLayout getSwipeRefreshLayout();
}
