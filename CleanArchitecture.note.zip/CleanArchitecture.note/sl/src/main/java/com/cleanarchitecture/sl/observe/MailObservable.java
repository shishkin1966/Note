package com.cleanarchitecture.sl.observe;

/**
 * Created by Shishkin on 12.02.2018.
 */

public interface MailObservable extends IObservable {
}
