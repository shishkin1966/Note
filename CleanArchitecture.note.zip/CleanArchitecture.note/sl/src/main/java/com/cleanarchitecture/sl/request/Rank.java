package com.cleanarchitecture.sl.request;

/**
 * Created by Shishkin on 13.01.2018.
 */

public class Rank {

    public static final int MAX_RANK = 10;
    public static final int HIGH_RANK = 8;
    public static final int MIDDLE_RANK = 5;
    public static final int LOW_RANK = 2;
    public static final int MIN_RANK = 0;

}
