package com.cleanarchitecture.sl.delegate;

/**
 * Created by Shishkin on 13.03.2018.
 */

public interface SenderDelegating {

    void processing(Object sender, Object object);


}
