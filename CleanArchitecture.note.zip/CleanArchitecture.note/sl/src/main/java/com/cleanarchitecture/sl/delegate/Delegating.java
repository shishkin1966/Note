package com.cleanarchitecture.sl.delegate;

/**
 * Created by Shishkin on 14.03.2018.
 */

public interface Delegating {

    void processing(Object object);

}
