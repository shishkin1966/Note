package com.cleanarchitecture.common.net;

public interface ConnectListener {

    void onConnect();

    void onDisconnect();
}
