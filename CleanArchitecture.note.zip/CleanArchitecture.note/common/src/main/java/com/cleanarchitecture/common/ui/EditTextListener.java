package com.cleanarchitecture.common.ui;

import android.widget.EditText;

/**
 * Created by Shishkin on 15.01.2018.
 */

public interface EditTextListener {

    void afterTextChanged(EditText editText);

}
